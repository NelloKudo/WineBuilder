# Custom patches directory

You can just paste your patches here and as long as the extension is **.patch**, you'll be fine :3
